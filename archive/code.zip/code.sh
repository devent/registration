#!/bin/bash
java -classpath "$PWD/schluessel.jar" devent.keygenerator.GeneratorAusSchluessel $1
